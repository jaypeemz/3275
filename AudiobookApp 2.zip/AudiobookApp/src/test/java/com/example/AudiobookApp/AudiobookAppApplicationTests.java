package com.example.AudiobookApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AudiobookAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
