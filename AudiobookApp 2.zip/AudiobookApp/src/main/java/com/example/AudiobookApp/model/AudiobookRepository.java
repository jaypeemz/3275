package com.example.AudiobookApp.model;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface AudiobookRepository extends JpaRepository<Audiobook, Long>{
//	@Query(value="SELECT audiobook, ARRAY_AGG(DISTINCT user) user FROM USER_FAVOURITES GROUP BY audiobook", nativeQuery = true)
	List<Audiobook> findByTitleContainingIgnoreCase(String title);
	
}

