package com.example.AudiobookApp.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.AudiobookApp.model.Playlist;
import com.example.AudiobookApp.model.PlaylistRepository;
import com.example.AudiobookApp.model.User;
import com.example.AudiobookApp.model.UserRepository;

@CrossOrigin(origins = "http://localhost:8080")
@RestController
@RequestMapping("/api")
public class PlaylistController {
	@Autowired
	PlaylistRepository playlistRepository;
	
	@GetMapping("/playlist")
	public ResponseEntity<List<Playlist>> getPlaylists(@RequestParam(required = false)String title){
		try {
			List<Playlist> playlists = new ArrayList<Playlist>();
			if(title==null) {
				playlistRepository.findAll().forEach(playlists::add);
			}else {
				playlistRepository.findPlaylistByName(title).forEach(playlists::add);
			}
			if(playlists.isEmpty()) {
				return new ResponseEntity<>(HttpStatus.NO_CONTENT);
			}
			
				return new ResponseEntity<>(playlists,HttpStatus.OK);
			
			
		} catch (Exception e) {
			return new ResponseEntity<>(null,HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	@PostMapping("/playlist")
	public ResponseEntity<Playlist> createPlaylist(@RequestBody Playlist playlist){
		try {
			Playlist _playlist = playlistRepository.save(new Playlist(playlist.getName(),playlist.getPlaylistOwner(),playlist.getAudiobooks()));
				return new ResponseEntity<>(_playlist,HttpStatus.CREATED); 
		} catch (Exception e) {
			return new ResponseEntity<>(null,HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	@PutMapping("/playlist/{id}")
	public ResponseEntity<Playlist> updatePlaylist(@PathVariable("id")long id, @RequestBody Playlist playlist){
		Optional<Playlist> playlistData = playlistRepository.findById(id);
		
		if (playlistData.isPresent()) {
			Playlist _playlist = playlistData.get();
			_playlist.setName(playlist.getName());
			_playlist.setPlaylistOwner(playlist.getPlaylistOwner());
			_playlist.setAudiobooks(playlist.getAudiobooks());
			return new ResponseEntity<>(playlistRepository.save(_playlist),HttpStatus.OK);
		}else {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
	}
	@DeleteMapping("/playlist/{id}")
	public ResponseEntity<HttpStatus> deleteUser(@PathVariable("id")long id){
		
		try {
			playlistRepository.deleteById(id);
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		} catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
			// TODO: handle exception
		}
	}
	@DeleteMapping("/playlist")
	public ResponseEntity<HttpStatus> deleteAllPlaylist(){
		try {
			playlistRepository.deleteAll();
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		} catch (Exception e) {
			return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
}
