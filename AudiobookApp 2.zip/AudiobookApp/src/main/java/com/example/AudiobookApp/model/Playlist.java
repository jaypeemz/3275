package com.example.AudiobookApp.model;

import java.util.ArrayList;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="playlist")
public class Playlist {
	
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;
	
	@Column(name = "name")
	private String name;
	
	@Column(name = "playlistOwner")
	private String playlistOwner;
	
	@Column(name = "audiobooks")
	private ArrayList<String> audiobooks= new ArrayList<>();
	
	public Playlist() {
		
	}
	
	public Playlist(String name,String playlistOwner,ArrayList<String> audiobooks) {
		this.name=name;
		this.playlistOwner=playlistOwner;
		this.audiobooks = (ArrayList<String>) audiobooks.clone();
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPlaylistOwner() {
		return playlistOwner;
	}

	public void setPlaylistOwner(String playlistOwner) {
		this.playlistOwner = playlistOwner;
	}

	public ArrayList<String> getAudiobooks() {
		return audiobooks;
	}

	public void setAudiobooks(ArrayList<String> audiobooks) {
		this.audiobooks = audiobooks;
	}
}
